﻿namespace _714230056_RaihanAdityaH_ATS
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNPM = new System.Windows.Forms.TextBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtKelas = new System.Windows.Forms.TextBox();
            this.txtTakademik = new System.Windows.Forms.TextBox();
            this.txtAlamat = new System.Windows.Forms.TextBox();
            this.rbCwok = new System.Windows.Forms.RadioButton();
            this.rbCewk = new System.Windows.Forms.RadioButton();
            this.cbPstudi = new System.Windows.Forms.ComboBox();
            this.bPMK = new System.Windows.Forms.Button();
            this.gbSemester = new System.Windows.Forms.GroupBox();
            this.rbSmster3 = new System.Windows.Forms.RadioButton();
            this.rbSmster2 = new System.Windows.Forms.RadioButton();
            this.rbSmster1 = new System.Windows.Forms.RadioButton();
            this.gbMKP = new System.Windows.Forms.GroupBox();
            this.cbSCM = new System.Windows.Forms.CheckBox();
            this.cbPkn = new System.Windows.Forms.CheckBox();
            this.cbAlgo2 = new System.Windows.Forms.CheckBox();
            this.cbAlgo1 = new System.Windows.Forms.CheckBox();
            this.cbLitedata = new System.Windows.Forms.CheckBox();
            this.cbBasisdata2 = new System.Windows.Forms.CheckBox();
            this.cbBasisdata1 = new System.Windows.Forms.CheckBox();
            this.cbLitek = new System.Windows.Forms.CheckBox();
            this.cbPmg2 = new System.Windows.Forms.CheckBox();
            this.cbPmg1 = new System.Windows.Forms.CheckBox();
            this.cbAljabar = new System.Windows.Forms.CheckBox();
            this.cbMTKdisk = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.epWrong = new System.Windows.Forms.ErrorProvider(this.components);
            this.epCorrect = new System.Windows.Forms.ErrorProvider(this.components);
            this.epWarning = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbSemester.SuspendLayout();
            this.gbMKP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epWrong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epCorrect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epWarning)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "NPM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nama";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Jenis Kelamin";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Alamat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(423, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Program Studi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(423, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tahun Akademik";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(423, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kelas";
            // 
            // txtNPM
            // 
            this.txtNPM.Location = new System.Drawing.Point(110, 21);
            this.txtNPM.Name = "txtNPM";
            this.txtNPM.Size = new System.Drawing.Size(186, 20);
            this.txtNPM.TabIndex = 7;
            this.txtNPM.TextChanged += new System.EventHandler(this.txtNPM_TextChanged);
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(110, 54);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(186, 20);
            this.txtNama.TabIndex = 8;
            this.txtNama.TextChanged += new System.EventHandler(this.txtNama_TextChanged);
            // 
            // txtKelas
            // 
            this.txtKelas.Location = new System.Drawing.Point(534, 88);
            this.txtKelas.Name = "txtKelas";
            this.txtKelas.Size = new System.Drawing.Size(186, 20);
            this.txtKelas.TabIndex = 9;
            this.txtKelas.TextChanged += new System.EventHandler(this.txtKelas_TextChanged);
            // 
            // txtTakademik
            // 
            this.txtTakademik.Location = new System.Drawing.Point(534, 54);
            this.txtTakademik.Name = "txtTakademik";
            this.txtTakademik.Size = new System.Drawing.Size(186, 20);
            this.txtTakademik.TabIndex = 10;
            this.txtTakademik.TextChanged += new System.EventHandler(this.txtTakademik_TextChanged);
            // 
            // txtAlamat
            // 
            this.txtAlamat.Location = new System.Drawing.Point(110, 122);
            this.txtAlamat.Multiline = true;
            this.txtAlamat.Name = "txtAlamat";
            this.txtAlamat.Size = new System.Drawing.Size(186, 81);
            this.txtAlamat.TabIndex = 11;
            this.txtAlamat.TextChanged += new System.EventHandler(this.txtAlamat_TextChanged);
            // 
            // rbCwok
            // 
            this.rbCwok.AutoSize = true;
            this.rbCwok.Location = new System.Drawing.Point(121, 89);
            this.rbCwok.Name = "rbCwok";
            this.rbCwok.Size = new System.Drawing.Size(74, 17);
            this.rbCwok.TabIndex = 12;
            this.rbCwok.TabStop = true;
            this.rbCwok.Text = "Laki - Laki";
            this.rbCwok.UseVisualStyleBackColor = true;
            this.rbCwok.CheckedChanged += new System.EventHandler(this.rbCwok_CheckedChanged);
            // 
            // rbCewk
            // 
            this.rbCewk.AutoSize = true;
            this.rbCewk.Location = new System.Drawing.Point(201, 89);
            this.rbCewk.Name = "rbCewk";
            this.rbCewk.Size = new System.Drawing.Size(79, 17);
            this.rbCewk.TabIndex = 13;
            this.rbCewk.TabStop = true;
            this.rbCewk.Text = "Perempuan";
            this.rbCewk.UseVisualStyleBackColor = true;
            this.rbCewk.CheckedChanged += new System.EventHandler(this.rbCewk_CheckedChanged);
            // 
            // cbPstudi
            // 
            this.cbPstudi.FormattingEnabled = true;
            this.cbPstudi.Location = new System.Drawing.Point(534, 21);
            this.cbPstudi.Name = "cbPstudi";
            this.cbPstudi.Size = new System.Drawing.Size(186, 21);
            this.cbPstudi.TabIndex = 14;
            this.cbPstudi.SelectedIndexChanged += new System.EventHandler(this.cbPstudi_SelectedIndexChanged);
            // 
            // bPMK
            // 
            this.bPMK.Location = new System.Drawing.Point(525, 155);
            this.bPMK.Name = "bPMK";
            this.bPMK.Size = new System.Drawing.Size(136, 48);
            this.bPMK.TabIndex = 15;
            this.bPMK.Text = "Pilih Mata Kuliah";
            this.bPMK.UseVisualStyleBackColor = true;
            this.bPMK.Click += new System.EventHandler(this.bPMK_Click);
            // 
            // gbSemester
            // 
            this.gbSemester.Controls.Add(this.rbSmster3);
            this.gbSemester.Controls.Add(this.rbSmster2);
            this.gbSemester.Controls.Add(this.rbSmster1);
            this.gbSemester.Location = new System.Drawing.Point(110, 262);
            this.gbSemester.Name = "gbSemester";
            this.gbSemester.Size = new System.Drawing.Size(200, 137);
            this.gbSemester.TabIndex = 16;
            this.gbSemester.TabStop = false;
            this.gbSemester.Text = "Semester ";
            // 
            // rbSmster3
            // 
            this.rbSmster3.AutoSize = true;
            this.rbSmster3.Location = new System.Drawing.Point(11, 79);
            this.rbSmster3.Name = "rbSmster3";
            this.rbSmster3.Size = new System.Drawing.Size(78, 17);
            this.rbSmster3.TabIndex = 2;
            this.rbSmster3.TabStop = true;
            this.rbSmster3.Text = "Semester 3";
            this.rbSmster3.UseVisualStyleBackColor = true;
            this.rbSmster3.CheckedChanged += new System.EventHandler(this.rbSmster3_CheckedChanged);
            // 
            // rbSmster2
            // 
            this.rbSmster2.AutoSize = true;
            this.rbSmster2.Location = new System.Drawing.Point(11, 56);
            this.rbSmster2.Name = "rbSmster2";
            this.rbSmster2.Size = new System.Drawing.Size(78, 17);
            this.rbSmster2.TabIndex = 1;
            this.rbSmster2.TabStop = true;
            this.rbSmster2.Text = "Semester 2";
            this.rbSmster2.UseVisualStyleBackColor = true;
            this.rbSmster2.CheckedChanged += new System.EventHandler(this.rbSmster2_CheckedChanged);
            // 
            // rbSmster1
            // 
            this.rbSmster1.AutoSize = true;
            this.rbSmster1.Location = new System.Drawing.Point(11, 33);
            this.rbSmster1.Name = "rbSmster1";
            this.rbSmster1.Size = new System.Drawing.Size(78, 17);
            this.rbSmster1.TabIndex = 0;
            this.rbSmster1.TabStop = true;
            this.rbSmster1.Text = "Semester 1";
            this.rbSmster1.UseVisualStyleBackColor = true;
            this.rbSmster1.CheckedChanged += new System.EventHandler(this.rbSmster1_CheckedChanged);
            // 
            // gbMKP
            // 
            this.gbMKP.Controls.Add(this.cbSCM);
            this.gbMKP.Controls.Add(this.cbPkn);
            this.gbMKP.Controls.Add(this.cbAlgo2);
            this.gbMKP.Controls.Add(this.cbAlgo1);
            this.gbMKP.Controls.Add(this.cbLitedata);
            this.gbMKP.Controls.Add(this.cbBasisdata2);
            this.gbMKP.Controls.Add(this.cbBasisdata1);
            this.gbMKP.Controls.Add(this.cbLitek);
            this.gbMKP.Controls.Add(this.cbPmg2);
            this.gbMKP.Controls.Add(this.cbPmg1);
            this.gbMKP.Controls.Add(this.cbAljabar);
            this.gbMKP.Controls.Add(this.cbMTKdisk);
            this.gbMKP.Location = new System.Drawing.Point(404, 262);
            this.gbMKP.Name = "gbMKP";
            this.gbMKP.Size = new System.Drawing.Size(373, 137);
            this.gbMKP.TabIndex = 17;
            this.gbMKP.TabStop = false;
            this.gbMKP.Text = "Mata Kuliah Pilihan";
            // 
            // cbSCM
            // 
            this.cbSCM.AutoSize = true;
            this.cbSCM.Location = new System.Drawing.Point(249, 94);
            this.cbSCM.Name = "cbSCM";
            this.cbSCM.Size = new System.Drawing.Size(49, 17);
            this.cbSCM.TabIndex = 11;
            this.cbSCM.Text = "SCM";
            this.cbSCM.UseVisualStyleBackColor = true;
            // 
            // cbPkn
            // 
            this.cbPkn.AutoSize = true;
            this.cbPkn.Location = new System.Drawing.Point(249, 71);
            this.cbPkn.Name = "cbPkn";
            this.cbPkn.Size = new System.Drawing.Size(45, 17);
            this.cbPkn.TabIndex = 10;
            this.cbPkn.Text = "Pkn";
            this.cbPkn.UseVisualStyleBackColor = true;
            // 
            // cbAlgo2
            // 
            this.cbAlgo2.AutoSize = true;
            this.cbAlgo2.Location = new System.Drawing.Point(249, 48);
            this.cbAlgo2.Name = "cbAlgo2";
            this.cbAlgo2.Size = new System.Drawing.Size(56, 17);
            this.cbAlgo2.TabIndex = 9;
            this.cbAlgo2.Text = "Algo II";
            this.cbAlgo2.UseVisualStyleBackColor = true;
            // 
            // cbAlgo1
            // 
            this.cbAlgo1.AutoSize = true;
            this.cbAlgo1.Location = new System.Drawing.Point(249, 25);
            this.cbAlgo1.Name = "cbAlgo1";
            this.cbAlgo1.Size = new System.Drawing.Size(53, 17);
            this.cbAlgo1.TabIndex = 8;
            this.cbAlgo1.Text = "Algo I";
            this.cbAlgo1.UseVisualStyleBackColor = true;
            // 
            // cbLitedata
            // 
            this.cbLitedata.AutoSize = true;
            this.cbLitedata.Location = new System.Drawing.Point(146, 94);
            this.cbLitedata.Name = "cbLitedata";
            this.cbLitedata.Size = new System.Drawing.Size(85, 17);
            this.cbLitedata.TabIndex = 7;
            this.cbLitedata.Text = "Literasi Data";
            this.cbLitedata.UseVisualStyleBackColor = true;
            // 
            // cbBasisdata2
            // 
            this.cbBasisdata2.AutoSize = true;
            this.cbBasisdata2.Location = new System.Drawing.Point(146, 71);
            this.cbBasisdata2.Name = "cbBasisdata2";
            this.cbBasisdata2.Size = new System.Drawing.Size(86, 17);
            this.cbBasisdata2.TabIndex = 6;
            this.cbBasisdata2.Text = "Basis Data II";
            this.cbBasisdata2.UseVisualStyleBackColor = true;
            // 
            // cbBasisdata1
            // 
            this.cbBasisdata1.AutoSize = true;
            this.cbBasisdata1.Location = new System.Drawing.Point(146, 48);
            this.cbBasisdata1.Name = "cbBasisdata1";
            this.cbBasisdata1.Size = new System.Drawing.Size(83, 17);
            this.cbBasisdata1.TabIndex = 5;
            this.cbBasisdata1.Text = "Basis Data I";
            this.cbBasisdata1.UseVisualStyleBackColor = true;
            // 
            // cbLitek
            // 
            this.cbLitek.AutoSize = true;
            this.cbLitek.Location = new System.Drawing.Point(146, 25);
            this.cbLitek.Name = "cbLitek";
            this.cbLitek.Size = new System.Drawing.Size(49, 17);
            this.cbLitek.TabIndex = 4;
            this.cbLitek.Text = "Litek";
            this.cbLitek.UseVisualStyleBackColor = true;
            // 
            // cbPmg2
            // 
            this.cbPmg2.AutoSize = true;
            this.cbPmg2.Location = new System.Drawing.Point(12, 94);
            this.cbPmg2.Name = "cbPmg2";
            this.cbPmg2.Size = new System.Drawing.Size(97, 17);
            this.cbPmg2.TabIndex = 3;
            this.cbPmg2.Text = "Pemograman II";
            this.cbPmg2.UseVisualStyleBackColor = true;
            // 
            // cbPmg1
            // 
            this.cbPmg1.AutoSize = true;
            this.cbPmg1.Location = new System.Drawing.Point(12, 71);
            this.cbPmg1.Name = "cbPmg1";
            this.cbPmg1.Size = new System.Drawing.Size(94, 17);
            this.cbPmg1.TabIndex = 2;
            this.cbPmg1.Text = "Pemograman I";
            this.cbPmg1.UseVisualStyleBackColor = true;
            // 
            // cbAljabar
            // 
            this.cbAljabar.AutoSize = true;
            this.cbAljabar.Location = new System.Drawing.Point(12, 48);
            this.cbAljabar.Name = "cbAljabar";
            this.cbAljabar.Size = new System.Drawing.Size(86, 17);
            this.cbAljabar.TabIndex = 1;
            this.cbAljabar.Text = "Aljabar Linier";
            this.cbAljabar.UseVisualStyleBackColor = true;
            // 
            // cbMTKdisk
            // 
            this.cbMTKdisk.AutoSize = true;
            this.cbMTKdisk.Location = new System.Drawing.Point(12, 25);
            this.cbMTKdisk.Name = "cbMTKdisk";
            this.cbMTKdisk.Size = new System.Drawing.Size(113, 17);
            this.cbMTKdisk.TabIndex = 0;
            this.cbMTKdisk.Text = "Matematika Diskrit";
            this.cbMTKdisk.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(151, 466);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 45);
            this.button1.TabIndex = 18;
            this.button1.Text = "Simpan";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);

            // button2
            // 
            this.button2.Location = new System.Drawing.Point(458, 466);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 45);
            this.button2.TabIndex = 18;
            this.button2.Text = "Batal";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // epWrong
            // 
            this.epWrong.ContainerControl = this;
            // 
            // epCorrect
            // 
            this.epCorrect.ContainerControl = this;
            this.epCorrect.Icon = ((System.Drawing.Icon)(resources.GetObject("epCorrect.Icon")));
            // 
            // epWarning
            // 
            this.epWarning.ContainerControl = this;
            this.epWarning.Icon = ((System.Drawing.Icon)(resources.GetObject("epWarning.Icon")));
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 587);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbMKP);
            this.Controls.Add(this.gbSemester);
            this.Controls.Add(this.bPMK);
            this.Controls.Add(this.cbPstudi);
            this.Controls.Add(this.rbCewk);
            this.Controls.Add(this.rbCwok);
            this.Controls.Add(this.txtAlamat);
            this.Controls.Add(this.txtTakademik);
            this.Controls.Add(this.txtKelas);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtNPM);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Pilihan Mata Kuliah";
            this.gbSemester.ResumeLayout(false);
            this.gbSemester.PerformLayout();
            this.gbMKP.ResumeLayout(false);
            this.gbMKP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epWrong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epCorrect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epWarning)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtNPM;
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtKelas;
        private System.Windows.Forms.TextBox txtTakademik;
        private System.Windows.Forms.TextBox txtAlamat;
        private System.Windows.Forms.RadioButton rbCwok;
        private System.Windows.Forms.RadioButton rbCewk;
        private System.Windows.Forms.ComboBox cbPstudi;
        private System.Windows.Forms.Button bPMK;
        private System.Windows.Forms.GroupBox gbSemester;
        private System.Windows.Forms.GroupBox gbMKP;
        private System.Windows.Forms.RadioButton rbSmster3;
        private System.Windows.Forms.RadioButton rbSmster2;
        private System.Windows.Forms.RadioButton rbSmster1;
        private System.Windows.Forms.CheckBox cbSCM;
        private System.Windows.Forms.CheckBox cbPkn;
        private System.Windows.Forms.CheckBox cbAlgo2;
        private System.Windows.Forms.CheckBox cbAlgo1;
        private System.Windows.Forms.CheckBox cbLitedata;
        private System.Windows.Forms.CheckBox cbBasisdata2;
        private System.Windows.Forms.CheckBox cbBasisdata1;
        private System.Windows.Forms.CheckBox cbLitek;
        private System.Windows.Forms.CheckBox cbPmg2;
        private System.Windows.Forms.CheckBox cbPmg1;
        private System.Windows.Forms.CheckBox cbAljabar;
        private System.Windows.Forms.CheckBox cbMTKdisk;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ErrorProvider epWrong;
        private System.Windows.Forms.ErrorProvider epCorrect;
        private System.Windows.Forms.ErrorProvider epWarning;
    }
}
